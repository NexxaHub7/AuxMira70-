# Sin minificación: reflexión de Shizuku.newProcess
-keep class rikka.shizuku.** { *; }
