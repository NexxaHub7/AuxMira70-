package com.lgang.injector

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Mono = FontFamily.Monospace
private val ErrC = Color(0xFFFF6B86)
private val Violet = Color(0xFFC4B5FD)

// ---------------- Router ----------------

@Composable
fun MainScreen(vm: MainViewModel) {
    BackHandler(enabled = vm.screen != MainViewModel.Screen.KEY) { vm.back() }
    Box(Modifier.fillMaxSize()) {
        AnimatedBackdrop()
        AnimatedContent(
            targetState = vm.screen,
            transitionSpec = {
                (fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 12 }).togetherWith(fadeOut(tween(200)))
            },
            label = "screen"
        ) { s ->
            when (s) {
                MainViewModel.Screen.KEY -> KeyScreen(vm)
                MainViewModel.Screen.WAIT -> WaitScreen(vm)
                MainViewModel.Screen.PICK -> PickScreen(vm)
                MainViewModel.Screen.PANEL -> PanelScreen(vm)
                MainViewModel.Screen.ADMIN -> AdminScreen(vm)
            }
        }
        if (vm.screen == MainViewModel.Screen.KEY) {
            val src = remember { MutableInteractionSource() }
            Text(
                "🔑",
                fontSize = 24.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .clickable(interactionSource = src, indication = null) { vm.onKeyTap() }
                    .padding(18.dp)
            )
        }
        if (vm.screen != MainViewModel.Screen.PANEL) {
            MadeBy(
                Modifier
                    .align(Alignment.BottomStart)
                    .navigationBarsPadding()
                    .padding(start = 14.dp, bottom = 10.dp)
            )
        }
        if (vm.ownerDialog) OwnerDialog(vm)
    }
}

@Composable
fun MadeBy(modifier: Modifier = Modifier) {
    Text("Made by hiddenart", color = Color(0xFF5D5D6E), fontSize = 10.sp, letterSpacing = 1.sp, modifier = modifier)
}

// ---------------- Componentes ----------------

@Composable
fun ShimmerTitle(text: String, size: TextUnit = 44.sp, spacing: TextUnit = 8.sp) {
    val t = rememberInfiniteTransition(label = "title")
    val shift by t.animateFloat(
        initialValue = 0f,
        targetValue = 700f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
        label = "shift"
    )
    Text(
        text,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth(),
        style = TextStyle(
            brush = Brush.horizontalGradient(
                colors = listOf(LgRed, LgPurple, LgRed),
                startX = shift,
                endX = shift + 350f,
                tileMode = TileMode.Mirror
            ),
            fontSize = size,
            fontWeight = FontWeight.Black,
            letterSpacing = spacing,
            textAlign = TextAlign.Center
        )
    )
}

@Composable
fun HaButton(
    text: String,
    ghost: Boolean = false,
    pulse: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val inf = rememberInfiniteTransition(label = "hb")
    val s = inf.animateFloat(
        initialValue = 1f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "s"
    )
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .graphicsLayer {
                val k = if (pulse) s.value else 1f
                scaleX = k
                scaleY = k
            }
            .clip(shape)
            .then(
                if (ghost) Modifier.border(1.dp, LgPurple, shape)
                else Modifier.background(Brush.horizontalGradient(listOf(LgRed, LgPurple)))
            )
            .alpha(if (enabled) 1f else 0.5f)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (ghost) Violet else Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 16.sp
        )
    }
}

@Composable
fun HaField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    number: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier.fillMaxWidth(),
        singleLine = true,
        placeholder = { Text(placeholder, color = LgMuted, fontFamily = Mono, fontSize = 14.sp) },
        textStyle = TextStyle(fontFamily = Mono, fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
        shape = RoundedCornerShape(14.dp),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = if (number) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = LgPurple,
            unfocusedBorderColor = LgBorder,
            focusedTextColor = LgText,
            unfocusedTextColor = LgText,
            cursorColor = LgPurple,
            focusedContainerColor = Color(0xFF0B0B10),
            unfocusedContainerColor = Color(0xFF0B0B10)
        )
    )
}

@Composable
fun HaCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(LgCard)
            .border(1.dp, LgBorder, shape)
            .padding(18.dp),
        content = content
    )
}

@Composable
fun Lbl(t: String) {
    Text(t, color = LgMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    Spacer(Modifier.height(6.dp))
}

@Composable
fun ChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, o ->
            val on = i == selected
            val c by animateColorAsState(if (on) LgPurple else LgBorder, tween(250), label = "chip")
            val shape = RoundedCornerShape(50)
            Text(
                o,
                color = if (on) Color.White else LgMuted,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(shape)
                    .background(if (on) LgPurple.copy(alpha = 0.35f) else Color.Transparent)
                    .border(1.dp, c, shape)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 13.dp, vertical = 7.dp)
            )
        }
    }
}

// ---------------- Key ----------------

@Composable
fun KeyScreen(vm: MainViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 18.dp)
    ) {
        Spacer(Modifier.height(48.dp))
        ShimmerTitle("HIDDEN ART")
        Text(
            "ACCESO PRIVADO", color = LgMuted, fontSize = 12.sp, letterSpacing = 4.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(28.dp))
        HaCard {
            Lbl("INTRODUCE TU KEY")
            HaField(vm.keyInput, { vm.keyInput = it }, "hiddenart-xxxxxxxx-xxxxxxxx")
            Text(
                vm.keyError, color = ErrC, fontSize = 13.sp,
                modifier = Modifier.padding(top = 8.dp, bottom = 8.dp).heightIn(min = 18.dp)
            )
            HaButton("🔓 Login") { vm.login() }
            Spacer(Modifier.height(10.dp))
            HaButton("🔑 Get Key", ghost = true, pulse = true) { vm.startWait() }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Las keys de Get Key son de un solo uso y duran 24 horas.",
            color = LgMuted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun WaitScreen(vm: MainViewModel) {
    val clip = LocalClipboardManager.current
    val frac by animateFloatAsState(1f - vm.waitLeft / WAIT_SECONDS.toFloat(), tween(1000, easing = LinearEasing), label = "ring")
    var copied by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 18.dp)
    ) {
        Spacer(Modifier.height(48.dp))
        ShimmerTitle("HIDDEN ART")
        Text(
            "GENERANDO TU KEY", color = LgMuted, fontSize = 12.sp, letterSpacing = 4.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(24.dp))
        HaCard {
            Box(Modifier.size(200.dp).align(Alignment.CenterHorizontally), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 10.dp.toPx()
                    val sz = Size(size.width - sw, size.height - sw)
                    val tl = Offset(sw / 2, sw / 2)
                    drawArc(LgBorder, -90f, 360f, false, tl, sz, style = Stroke(sw))
                    drawArc(
                        Brush.linearGradient(listOf(LgRed, LgPurple)), -90f, 360f * frac, false, tl, sz,
                        style = Stroke(sw, cap = StrokeCap.Round)
                    )
                }
                Text(
                    "%d:%02d".format(vm.waitLeft / 60, vm.waitLeft % 60),
                    fontSize = 42.sp, fontWeight = FontWeight.Black, fontFamily = Mono
                )
            }
            Spacer(Modifier.height(14.dp))
            val k = vm.generatedKey
            if (k == null) {
                Text(
                    "Espera a que termine el contador…", color = LgMuted, fontSize = 12.sp,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
            } else {
                AnimatedVisibility(visible = true) {
                    Column {
                        val shape = RoundedCornerShape(14.dp)
                        Text(
                            k, color = Violet, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(shape)
                                .background(Color(0xFF0B0B10))
                                .border(1.dp, LgPurple, shape)
                                .padding(14.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        HaButton(if (copied) "✅ Copiada" else "📋 Copiar key") {
                            clip.setText(AnnotatedString(k))
                            copied = true
                        }
                        Spacer(Modifier.height(10.dp))
                        HaButton("Usar key →", ghost = true) { vm.useGenerated() }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Un solo uso · caduca en 24 horas", color = LgMuted, fontSize = 12.sp,
                            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        HaButton("← Volver", ghost = true) { vm.back() }
    }
}

// ---------------- Escoger Free Fire ----------------

@Composable
fun PickScreen(vm: MainViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 18.dp)
    ) {
        Spacer(Modifier.height(48.dp))
        ShimmerTitle("HIDDEN ART")
        Text(
            "KEY VÁLIDA ✓", color = LgGreen, fontSize = 12.sp, letterSpacing = 4.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(28.dp))
        Text(
            "Escoge qué Free Fire tienes.", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        PickCard(vm, "🔥", "Freefire normal", PKG_NORMAL)
        Spacer(Modifier.height(12.dp))
        PickCard(vm, "💎", "Freefire Max", PKG_MAX)
    }
}

@Composable
fun PickCard(vm: MainViewModel, emoji: String, title: String, pkg: String) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.97f else 1f, spring(), label = "press")
    val border by animateColorAsState(if (pressed) LgPurple else LgBorder, tween(200), label = "pb")
    val installed = GameFinder.isInstalled(LocalContext.current, pkg)
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(shape)
            .background(LgCard)
            .border(1.dp, border, shape)
            .clickable(interactionSource = src, indication = null) { vm.choosePkg(pkg) }
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji, fontSize = 34.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(pkg, color = LgMuted, fontFamily = Mono, fontSize = 12.sp)
        }
        Text(
            if (installed) "INSTALADO" else "NO INSTALADO",
            color = if (installed) LgGreen else LgAmber,
            fontSize = 9.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp
        )
    }
}

// ---------------- Owner ----------------

@Composable
fun OwnerDialog(vm: MainViewModel) {
    var text by remember { mutableStateOf("") }
    val locked = vm.ownerLocked
    AlertDialog(
        onDismissRequest = { vm.closeOwner() },
        containerColor = LgCard,
        shape = RoundedCornerShape(22.dp),
        text = {
            Column {
                if (!locked) HaField(text, { text = it }, "Key", password = true)
                if (vm.ownerMsg.isNotEmpty()) {
                    Text(vm.ownerMsg, color = ErrC, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        },
        confirmButton = {
            if (!locked) {
                TextButton(onClick = { vm.ownerSubmit(text); text = "" }) {
                    Text("Entrar", color = LgPurple, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = { vm.closeOwner() }) { Text("Cerrar", color = LgMuted) }
        }
    )
}

// ---------------- Admin ----------------

@Composable
fun AdminScreen(vm: MainViewModel) {
    val clip = LocalClipboardManager.current
    var custom by remember { mutableStateOf(false) }
    var prefix by remember { mutableStateOf("hiddenart") }
    var cs by remember { mutableStateOf(Charset.HEX) }
    var blocks by remember { mutableStateOf("2") }
    var digits by remember { mutableStateOf("8") }
    var qty by remember { mutableStateOf("1") }
    var cus by remember { mutableStateOf("") }
    var dur by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf(2) }
    var uses by remember { mutableStateOf("1") }
    var out by remember { mutableStateOf(listOf<String>()) }
    var err by remember { mutableStateOf("") }

    fun n(s: String, d: Int, lo: Int, hi: Int) = (s.toIntOrNull() ?: d).coerceIn(lo, hi)
    val unitMs = longArrayOf(60_000L, 3_600_000L, DAY_MS)
    val opts = GenOpts(
        prefix = prefix,
        blocks = n(blocks, 2, 1, 6),
        digits = n(digits, 8, 1, 16),
        charset = cs,
        durMs = if (unit == 3) 0L else n(dur, 1, 1, 99999) * unitMs[unit.coerceAtMost(2)],
        max = n(uses, 1, 1, 9999)
    )
    val preview = remember(prefix, cs, blocks, digits, cus, custom) {
        if (custom) vm.keys.clean(cus).ifEmpty { "hola-67" } else vm.keys.mk(opts)
    }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 56.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ShimmerTitle("Panel Admin - Owner", 26.sp, 0.sp) }
        item {
            HaCard {
                Text("🔑 GENERAR KEYS", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(12.dp))
                ChipRow(listOf("Aleatoria", "Custom"), if (custom) 1 else 0) { custom = it == 1 }
                Spacer(Modifier.height(14.dp))
                if (!custom) {
                    Lbl("PREFIJO")
                    HaField(prefix, { prefix = it }, "hiddenart")
                    Spacer(Modifier.height(10.dp))
                    Lbl("TIPO")
                    ChipRow(Charset.values().map { it.label }, cs.ordinal) { cs = Charset.values()[it] }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(Modifier.weight(1f)) { Lbl("BLOQUES"); HaField(blocks, { blocks = it.filter(Char::isDigit).take(1) }, "2", number = true) }
                        Column(Modifier.weight(1f)) { Lbl("DÍGITOS"); HaField(digits, { digits = it.filter(Char::isDigit).take(2) }, "8", number = true) }
                        Column(Modifier.weight(1f)) { Lbl("CANTIDAD"); HaField(qty, { qty = it.filter(Char::isDigit).take(2) }, "1", number = true) }
                    }
                } else {
                    Lbl("KEY CUSTOM")
                    HaField(cus, { cus = it }, "hola-67")
                }
                Spacer(Modifier.height(14.dp))
                Lbl("DURACIÓN")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    HaField(dur, { dur = it.filter(Char::isDigit).take(5) }, "1", Modifier.weight(1f), number = true)
                    Spacer(Modifier.width(2.dp))
                }
                Spacer(Modifier.height(8.dp))
                ChipRow(listOf("Minutos", "Horas", "Días", "Permanente"), unit) { unit = it }
                Spacer(Modifier.height(8.dp))
                ChipRow(listOf("1 h", "1 día", "7 días", "30 días", "∞"), -1) {
                    when (it) {
                        0 -> { dur = "1"; unit = 1 }
                        1 -> { dur = "1"; unit = 2 }
                        2 -> { dur = "7"; unit = 2 }
                        3 -> { dur = "30"; unit = 2 }
                        else -> unit = 3
                    }
                }
                Spacer(Modifier.height(14.dp))
                Lbl("USOS POR KEY")
                HaField(uses, { uses = it.filter(Char::isDigit).take(4) }, "1", number = true)
                Spacer(Modifier.height(14.dp))
                Lbl("VISTA PREVIA")
                Text(
                    preview, color = Violet, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0B0B10))
                        .padding(14.dp)
                )
                Text(err, color = ErrC, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp).heightIn(min = 18.dp))
                HaButton("⚡ Generar", pulse = true) {
                    val r = vm.adminGenerate(if (custom) cus else null, opts, n(qty, 1, 1, 50))
                    out = r.first
                    err = r.second
                }
                if (out.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        out.joinToString("\n"), color = Violet, fontFamily = Mono, fontWeight = FontWeight.Bold,
                        fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0B0B10))
                            .border(1.dp, LgPurple, RoundedCornerShape(14.dp))
                            .padding(14.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    HaButton("📋 Copiar ${if (out.size > 1) "todas" else "key"}", ghost = true) {
                        clip.setText(AnnotatedString(out.joinToString("\n")))
                    }
                }
            }
        }
        item {
            Text("KEYS (${vm.keyList.size})", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, letterSpacing = 2.sp)
        }
        items(vm.keyList, key = { it.key }) { k ->
            KeyRow(k, onCopy = { clip.setText(AnnotatedString(k.key)) }, onDelete = { vm.adminDelete(k.key) })
        }
        item { HaButton("🧹 Borrar expiradas y usadas", ghost = true) { vm.adminClean() } }
        item { HaButton("← Salir", ghost = true) { vm.back() } }
    }
}

@Composable
fun KeyRow(k: KeyInfo, onCopy: () -> Unit, onDelete: () -> Unit) {
    val (label, col) = when {
        k.expired -> "EXPIRADA" to ErrC
        k.spent -> "USADA" to LgAmber
        else -> "ACTIVA" to LgGreen
    }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xFF0B0B10))
            .border(1.dp, LgBorder, shape)
            .padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(k.key, color = Violet, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            Text(
                "${k.used}/${k.max} usos · " + (if (k.exp == 0L) "permanente" else "vence ${fmt.format(Date(k.exp))}"),
                color = LgMuted, fontSize = 11.sp
            )
        }
        Text(
            label, color = col, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(col.copy(alpha = 0.13f))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        )
        Text("📋", modifier = Modifier.clickable { onCopy() }.padding(8.dp))
        Text("✕", color = LgMuted, modifier = Modifier.clickable { onDelete() }.padding(8.dp))
    }
}
