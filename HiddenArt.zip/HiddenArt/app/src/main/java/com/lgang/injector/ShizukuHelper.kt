package com.lgang.injector

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

data class ExecResult(val code: Int, val out: String) {
    val failed: Boolean
        get() = code != 0 || BAD.containsMatchIn(out)

    private companion object {
        val BAD = Regex("exception|error|denied|failed|unknown command", RegexOption.IGNORE_CASE)
    }
}

/** Escapa un valor para shell con comillas simples. */
fun q(s: String): String = "'" + s.replace("'", "'\\''") + "'"

object ShizukuHelper {

    fun isRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun hasPermission(): Boolean = try {
        isRunning() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun uid(): Int = try { Shizuku.getUid() } catch (_: Throwable) { -1 }

    fun isRoot(): Boolean = uid() == 0

    fun modeLabel(): String = when (uid()) {
        0 -> "ROOT"
        2000 -> "ADB"
        else -> "SHIZUKU"
    }

    // Shizuku.newProcess es privado desde la API 13: se usa por reflexión.
    private val newProcessMethod by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    suspend fun exec(cmd: String): ExecResult = withContext(Dispatchers.IO) {
        try {
            val p = newProcessMethod.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText().trim()
            val code = p.waitFor()
            ExecResult(code, out)
        } catch (t: Throwable) {
            ExecResult(-1, "Error: ${t.cause?.message ?: t.message}")
        }
    }
}
