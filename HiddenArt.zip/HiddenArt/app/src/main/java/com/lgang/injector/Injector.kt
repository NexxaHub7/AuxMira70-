package com.lgang.injector

import android.content.Context

enum class Outcome { OK, PARTIAL, NO_GAME, NO_ROOT }

object GameFinder {
    val packages = listOf(PKG_NORMAL, PKG_MAX)

    fun isInstalled(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: Exception) {
        false
    }

    fun find(ctx: Context): String? = packages.firstOrNull {
        try {
            ctx.packageManager.getPackageInfo(it, 0)
            true
        } catch (_: Exception) {
            false
        }
    }
}

class Injector(context: Context) {

    private val prefs = context.getSharedPreferences("lgang_backup", Context.MODE_PRIVATE)

    private fun bk(p: Put) = "put|${p.ns}|${p.key}"
    private fun bk(p: Prop) = "prop|${p.key}"

    suspend fun apply(f: Feature, game: String?): Outcome {
        var bad = false
        var ran = false
        var noGame = false
        var noRoot = false

        // ---- settings put ----
        val puts = f.ops.filterIsInstance<Put>()
        if (puts.isNotEmpty()) {
            val pending = puts.filter { !prefs.contains(bk(it)) }
            if (pending.isNotEmpty()) {
                val lines = ShizukuHelper.exec(
                    pending.joinToString("; ") { "echo \"=\$(settings get ${it.ns} ${it.key})\"" }
                ).out.lines()
                val e = prefs.edit()
                pending.forEachIndexed { i, p ->
                    e.putString(bk(p), lines.getOrNull(i)?.trim()?.removePrefix("=").orEmpty().ifEmpty { "null" })
                }
                e.apply()
            }
            val r = ShizukuHelper.exec(
                puts.joinToString("; ") { "settings put ${it.ns} ${it.key} ${q(it.value)}" }
            )
            if (r.failed) bad = true
            ran = true
        }

        // ---- setprop ----
        val props = f.ops.filterIsInstance<Prop>()
        if (props.isNotEmpty()) {
            val pending = props.filter { !prefs.contains(bk(it)) }
            if (pending.isNotEmpty()) {
                val lines = ShizukuHelper.exec(
                    pending.joinToString("; ") { "echo \"=\$(getprop ${it.key})\"" }
                ).out.lines()
                val e = prefs.edit()
                pending.forEachIndexed { i, p -> e.putString(bk(p), lines.getOrNull(i)?.trim()?.removePrefix("=").orEmpty()) }
                e.apply()
            }
            val r = ShizukuHelper.exec(
                props.joinToString("; ") { "setprop ${it.key} ${q(it.value)}" }
            )
            if (r.failed) bad = true
            ran = true
        }

        // ---- comandos shell ----
        for (s in f.ops.filterIsInstance<Sh>()) {
            if (s.needsRoot && !ShizukuHelper.isRoot()) { noRoot = true; continue }
            if (s.needsGame && game == null) { noGame = true; continue }
            val r = ShizukuHelper.exec(s.cmd.replace("{pkg}", game.orEmpty()))
            if (r.failed) bad = true
            ran = true
        }

        return when {
            !ran && noRoot -> Outcome.NO_ROOT
            !ran && noGame -> Outcome.NO_GAME
            bad -> Outcome.PARTIAL
            else -> Outcome.OK
        }
    }

    suspend fun revert(f: Feature, game: String?) {
        if (f.oneShot) return
        val cmds = mutableListOf<String>()
        for (op in f.ops) {
            when (op) {
                is Put -> prefs.getString(bk(op), null)?.let { orig ->
                    cmds.add(
                        if (orig == "null" || orig.isEmpty()) {
                            "settings delete ${op.ns} ${op.key}"
                        } else {
                            "settings put ${op.ns} ${op.key} ${q(orig)}"
                        }
                    )
                }
                is Prop -> prefs.getString(bk(op), null)?.let { cmds.add("setprop ${op.key} ${q(it)}") }
                is Sh -> op.undo?.let {
                    val okRoot = !op.needsRoot || ShizukuHelper.isRoot()
                    val okGame = !op.needsGame || game != null
                    if (okRoot && okGame) cmds.add(it.replace("{pkg}", game.orEmpty()))
                }
            }
        }
        if (cmds.isNotEmpty()) ShizukuHelper.exec(cmds.joinToString("; "))
        val e = prefs.edit()
        f.ops.forEach {
            when (it) {
                is Put -> e.remove(bk(it))
                is Prop -> e.remove(bk(it))
                is Sh -> {}
            }
        }
        e.apply()
    }
}
