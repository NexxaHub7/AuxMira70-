package com.lgang.injector

const val DISCLAIMER = "No nos hacemos responsables de daños en tu dispositivo."
const val DISCLAIMER2 = "Si aplicas la resolución y dpi, puede haber daños. Si no hay daños, la resolución y dpi cambian mucho la sensibilidad de tu celular, tienes que ajustar tu sensibilidad."
const val PKG_NORMAL = "com.dts.freefireth"
const val PKG_MAX = "com.dts.freefiremax"

enum class Effect(val label: String) { REAL("EFECTIVO"), ROM("SEGÚN ROM") }

sealed interface Op

/** settings put <ns> <key> <value> (se guarda el valor original para restaurar) */
data class Put(val ns: String, val key: String, val value: String) : Op

/** setprop <key> <value> */
data class Prop(val key: String, val value: String) : Op

/** Comando shell. {pkg} = paquete de Free Fire detectado. */
data class Sh(
    val cmd: String,
    val undo: String? = null,
    val needsGame: Boolean = false,
    val needsRoot: Boolean = false
) : Op

data class Feature(
    val id: String,
    val emoji: String,
    val title: String,
    val desc: String,
    val effect: Effect,
    val ops: List<Op>,
    val oneShot: Boolean = false,
    val defaultOn: Boolean = true
)

data class Section(val title: String, val features: List<Feature>)

private fun props(vararg p: Pair<String, String>) = p.map { Prop(it.first, it.second) }

object Features {
    val sections: List<Section> = listOf(
        Section(
            "⚡ RENDIMIENTO", listOf(
                Feature(
                    "perf", "🔋", "Performance",
                    "Desactiva el ahorro de batería (low_power 0).",
                    Effect.REAL, listOf(Put("global", "low_power", "0"))
                ),
                Feature(
                    "anim", "🎞️", "Animaciones OFF",
                    "Ventanas, transiciones y animadores a 0: la UI responde al instante.",
                    Effect.REAL, listOf(
                        Put("global", "window_animation_scale", "0"),
                        Put("global", "transition_animation_scale", "0"),
                        Put("global", "animator_duration_scale", "0")
                    )
                ),
                Feature(
                    "bg", "🧹", "Background Process",
                    "Limita procesos en segundo plano y apps cacheadas.",
                    Effect.ROM, listOf(
                        Put("global", "limit_background_processes", "1"),
                        Put("global", "max_cached_processes", "4")
                    )
                ),
                Feature(
                    "mem", "🧠", "Memoria",
                    "Congela apps cacheadas y activa app standby.",
                    Effect.REAL, listOf(
                        Put("global", "cached_apps_freezer", "enabled"),
                        Put("global", "app_standby_enabled", "1")
                    )
                ),
                Feature(
                    "clean", "🗑️", "Limpiar caché",
                    "Libera la caché de las apps (acción única).",
                    Effect.REAL, listOf(Sh("pm trim-caches 999999999")), oneShot = true
                ),
                Feature(
                    "compile", "🛠️", "Compilar Free Fire",
                    "Compila el juego en modo speed, en segundo plano (acción única, tarda).",
                    Effect.REAL,
                    listOf(Sh("(cmd package compile -m speed -f {pkg} >/dev/null 2>&1 &)", needsGame = true)),
                    oneShot = true, defaultOn = false
                )
            )
        ),
        Section(
            "🎯 TÁCTIL / MIRA", listOf(
                Feature(
                    "aim", "🎯", "Mira Estable",
                    "Filtro anti-ruido y anti-jitter del touch, zona muerta y escala de presión/distancia.",
                    Effect.ROM, listOf(
                        Put("system", "touch_filter_enable", "1"),
                        Put("system", "touch_noise_suppression", "1"),
                        Put("system", "touch_jitter_suppression", "1"),
                        Put("system", "touch_filter_deadzone_radius", "0.1"),
                        Put("system", "touch_area_filtering_enable", "1"),
                        Put("system", "touch_pressure_scale", "0.55"),
                        Put("system", "touch_distance_scale", "0.40"),
                        Put("system", "touch.filter.level", "2"),
                        Put("system", "touch.pressure.scale", "0.001")
                    )
                ),
                Feature(
                    "touch", "⚡", "Respuesta Táctil",
                    "Más eventos por segundo, muestreo y predicción del touch.",
                    Effect.ROM, listOf(
                        Put("system", "max_events_per_second", "300"),
                        Put("system", "max_pointer_events_per_second", "300"),
                        Put("system", "touch_response_boost", "1"),
                        Put("system", "input_sample_rate", "120"),
                        Put("system", "input_sample_priority", "1"),
                        Put("global", "touch_sampling_rate", "2"),
                        Put("global", "touch_prediction_enabled", "1"),
                        Put("system", "touch_sensitivity", "1"),
                        Put("global", "multi_touch_enabled", "1")
                    )
                ),
                Feature(
                    "sensi", "👆", "Sensi / Toques",
                    "Long press 250 ms, slop, puntero y scroll ajustados.",
                    Effect.ROM, listOf(
                        Put("secure", "long_press_timeout", "250"),
                        Put("global", "tap_duration_threshold", "0"),
                        Put("system", "touch_slop", "3"),
                        Put("global", "touch_slop", "2"),
                        Put("secure", "drag_min_distance", "5"),
                        Put("secure", "touch_blocking_period", "10"),
                        Put("system", "pointer_speed", "7"),
                        Put("system", "pointer_acceleration", "0"),
                        Put("system", "scroll_friction", "0.020"),
                        Put("system", "fling_deceleration", "250")
                    )
                ),
                Feature(
                    "supresor", "🛡️", "Supresor Alterado",
                    "accessibility_autoclick_delay = 999955555 (valor exacto).",
                    Effect.ROM, listOf(Put("secure", "accessibility_autoclick_delay", "999955555"))
                )
            )
        ),
        Section(
            "🖥️ PANTALLA", listOf(
                Feature(
                    "hz", "📺", "Refresh 120 Hz",
                    "Fuerza peak/min refresh rate a 120 Hz (si tu pantalla lo soporta).",
                    Effect.REAL, listOf(
                        Put("system", "peak_refresh_rate", "120.0"),
                        Put("system", "min_refresh_rate", "120.0")
                    )
                ),
                Feature(
                    "res", "📐", "Resolución 1500x3500",
                    "wm size 1500x3500. Se restaura con wm size reset.",
                    Effect.REAL, listOf(Sh("wm size 1500x3500", undo = "wm size reset"))
                ),
                Feature(
                    "dpi", "🔍", "DPI 510",
                    "wm density 510. Se restaura con wm density reset.",
                    Effect.REAL, listOf(Sh("wm density 510", undo = "wm density reset"))
                ),
                Feature(
                    "sat", "🎨", "Colores vivos",
                    "Saturación x1.5 de toda la pantalla (Android no permite subirla solo para un juego). Requiere Shizuku en modo ROOT.",
                    Effect.ROM, listOf(
                        Sh(
                            "service call SurfaceFlinger 1022 f 1.5",
                            undo = "service call SurfaceFlinger 1022 f 1.0",
                            needsRoot = true
                        )
                    )
                )
            )
        ),
        Section(
            "🚀 RENDER / GPU", listOf(
                Feature(
                    "fps", "🚀", "FPS Boost",
                    "Props de render y GPU (swapinterval, SurfaceFlinger, HWUI Skia). Se resetean al reiniciar el teléfono.",
                    Effect.ROM,
                    props(
                        "debug.gr.swapinterval" to "0",
                        "debug.egl.swapinterval" to "0",
                        "debug.egl.hw" to "1",
                        "debug.sf.hw" to "1",
                        "debug.performance.tuning" to "1",
                        "debug.sf.showupdates" to "0",
                        "debug.sf.showcpu" to "0",
                        "debug.sf.showbackground" to "0",
                        "debug.sf.showfps" to "0",
                        "debug.sf.enable_hwc_vds" to "1",
                        "debug.sf.disable_backpressure" to "1",
                        "debug.sf.no_hw_vsync" to "0",
                        "debug.sf.latch_unsignaled" to "1",
                        "debug.egl.buffcount" to "3",
                        "debug.hwui.renderer" to "skiagl",
                        "debug.hwui.use_buffer_age" to "true",
                        "debug.hwui.disable_vsync" to "false",
                        "debug.gralloc.enable_fb_ubwc" to "1",
                        "debug.sf.enable_gl_backpressure" to "1"
                    ) + Put("global", "debug.egl.force_msaa", "0")
                )
            )
        )
    )

    val all: List<Feature> get() = sections.flatMap { it.features }
}
