package com.lgang.injector

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---------------- Tema ----------------

val LgBg = Color(0xFF07070B)
val LgCard = Color(0xFF13131B)
val LgBorder = Color(0xFF24242F)
val LgRed = Color(0xFFFF2D55)
val LgPurple = Color(0xFF8B5CF6)
val LgGreen = Color(0xFF22C55E)
val LgTeal = Color(0xFF14B8A6)
val LgAmber = Color(0xFFF59E0B)
val LgText = Color(0xFFF2F2F7)
val LgMuted = Color(0xFF8E8E9F)

@Composable
fun LGangTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = LgRed,
            secondary = LgPurple,
            background = LgBg,
            surface = LgCard
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = LgBg, contentColor = LgText) {
            content()
        }
    }
}

// ---------------- Pantalla principal ----------------

@Composable
fun PanelScreen(vm: MainViewModel) {
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentPadding = PaddingValues(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "header") { Header(vm) }
            item(key = "inject") { InjectButton(vm) }
            item(key = "log") { LogPanel(vm) }
            item(key = "bulk") { BulkRow(vm) }

            Features.sections.forEach { section ->
                item(key = "t_${section.title}") { SectionTitle(section.title) }
                section.features.forEachIndexed { idx, f ->
                    item(key = f.id) {
                        FeatureCard(
                            f = f,
                            on = vm.enabled[f.id] == true,
                            delayMs = (idx % 6) * 55L,
                            onChange = { vm.setEnabled(f.id, it) }
                        )
                    }
                }
            }

            item(key = "footer") { Footer(vm) }
        }
    }
}

@Composable
fun AnimatedBackdrop() {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "a"
    )
    Canvas(Modifier.fillMaxSize()) {
        val r = size.minDimension * 0.9f
        val c1 = Offset(size.width * (0.1f + 0.6f * a), size.height * 0.08f)
        drawCircle(
            brush = Brush.radialGradient(listOf(LgRed.copy(alpha = 0.26f), Color.Transparent), center = c1, radius = r),
            radius = r,
            center = c1
        )
        val c2 = Offset(size.width * (0.9f - 0.6f * a), size.height * 0.55f)
        drawCircle(
            brush = Brush.radialGradient(listOf(LgPurple.copy(alpha = 0.22f), Color.Transparent), center = c2, radius = r),
            radius = r,
            center = c2
        )
    }
}

// ---------------- Header ----------------

@Composable
fun Header(vm: MainViewModel) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        ShimmerTitle("Auxilio de mira legal - Hidden Art.", 26.sp, 0.sp)
        Spacer(Modifier.height(14.dp))
        ShizukuChip(vm)
        Spacer(Modifier.height(10.dp))
        PackageChip(vm)
        AnimatedVisibility(
            visible = vm.message != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Text(
                vm.message.orEmpty(),
                color = LgAmber,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
fun PackageChip(vm: MainViewModel) {
    val ok = vm.game != null
    val col = if (ok) LgPurple else LgAmber
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(col.copy(alpha = 0.12f))
            .border(1.dp, col.copy(alpha = 0.5f), shape)
            .padding(start = 14.dp, top = 5.dp, bottom = 5.dp, end = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "🎮 ${vm.pkg.orEmpty()}" + if (ok) "" else " · no instalado",
            color = col, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.width(10.dp))
        Pill("Cambiar", col) { vm.changePkg() }
    }
}

@Composable
fun ShizukuChip(vm: MainViewModel) {
    val (txt, col) = when (vm.sz) {
        MainViewModel.Sz.READY -> "Shizuku · ${vm.szMode}" to LgGreen
        MainViewModel.Sz.NO_PERM -> "Shizuku sin permiso · toca para conceder" to LgAmber
        MainViewModel.Sz.OFF -> "Shizuku requerido · toca para abrir" to LgRed
    }
    val color by animateColorAsState(col, tween(400), label = "chip")
    val inf = rememberInfiniteTransition(label = "dot")
    val pulse by inf.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "pulse"
    )
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .animateContentSize()
            .clip(shape)
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.55f), shape)
            .clickable { vm.onShizukuTap() }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(8.dp)
                .alpha(pulse)
                .background(color, CircleShape)
        )
        Spacer(Modifier.width(8.dp))
        Text(txt, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

// ---------------- Botón Inyectar ----------------

@Composable
fun InjectButton(vm: MainViewModel) {
    val phase = vm.phase
    val c1 by animateColorAsState(
        when (phase) {
            MainViewModel.Phase.IDLE -> LgRed
            MainViewModel.Phase.RUNNING -> LgPurple
            MainViewModel.Phase.DONE -> LgGreen
            MainViewModel.Phase.ERROR -> Color(0xFF9F1239)
        }, tween(500), label = "c1"
    )
    val c2 by animateColorAsState(
        when (phase) {
            MainViewModel.Phase.IDLE -> LgPurple
            MainViewModel.Phase.RUNNING -> LgRed
            MainViewModel.Phase.DONE -> LgTeal
            MainViewModel.Phase.ERROR -> LgRed
        }, tween(500), label = "c2"
    )
    val inf = rememberInfiniteTransition(label = "btn")
    val pulse = inf.animateFloat(
        initialValue = 1f,
        targetValue = 1.025f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val prog by animateFloatAsState(vm.progress, tween(300), label = "prog")
    val glow by animateDpAsState(if (phase == MainViewModel.Phase.IDLE) 18.dp else 4.dp, tween(400), label = "glow")
    val shape = RoundedCornerShape(22.dp)

    Box(
        Modifier
            .fillMaxWidth()
            .height(68.dp)
            .graphicsLayer {
                val s = if (phase == MainViewModel.Phase.IDLE) pulse.value else 1f
                scaleX = s
                scaleY = s
            }
            .shadow(glow, shape, ambientColor = c1, spotColor = c1)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(c1, c2)))
            .clickable(enabled = phase != MainViewModel.Phase.RUNNING) { vm.inject() },
        contentAlignment = Alignment.Center
    ) {
        if (phase == MainViewModel.Phase.RUNNING) {
            Box(
                Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxHeight()
                    .fillMaxWidth(prog)
                    .background(Color.White.copy(alpha = 0.2f))
            )
        }
        AnimatedContent(targetState = phase, label = "btnText") { p ->
            Text(
                when (p) {
                    MainViewModel.Phase.IDLE -> "💉 Inyectar En FreeFire"
                    MainViewModel.Phase.RUNNING -> "Inyectando… ${(vm.progress * 100).toInt()}%"
                    MainViewModel.Phase.DONE -> "✅ Inyectado"
                    MainViewModel.Phase.ERROR -> "⚠️ Error · tocar para reintentar"
                },
                color = Color.White,
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )
        }
    }
}

// ---------------- Log ----------------

@Composable
fun LogPanel(vm: MainViewModel) {
    AnimatedVisibility(
        visible = vm.log.isNotEmpty(),
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically()
    ) {
        val shape = RoundedCornerShape(16.dp)
        Column(
            Modifier
                .fillMaxWidth()
                .animateContentSize()
                .clip(shape)
                .background(Color(0xFF0B0B10))
                .border(1.dp, LgBorder, shape)
                .padding(14.dp)
        ) {
            Text("▌ TERMINAL", color = LgPurple, fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            vm.log.takeLast(14).forEach { LogLine(it) }
        }
    }
}

@Composable
fun LogLine(text: String) {
    val state = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(
        visibleState = state,
        enter = fadeIn(tween(250)) + slideInHorizontally(tween(250)) { -it / 4 }
    ) {
        val color = when {
            text.startsWith("✓") || text.startsWith("🚀") || text.startsWith("↩") -> LgGreen
            text.startsWith("⚠") -> LgAmber
            text.startsWith("✗") -> LgRed
            else -> LgMuted
        }
        Text(text, color = color, fontFamily = FontFamily.Monospace, fontSize = 12.5.sp, lineHeight = 17.sp)
    }
}

// ---------------- Toggles ----------------

@Composable
fun BulkRow(vm: MainViewModel) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("TOGGLES", color = LgMuted, fontSize = 12.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Pill("Todos ON", LgPurple) { vm.setAll(true) }
        Spacer(Modifier.width(8.dp))
        Pill("Todos OFF", LgMuted) { vm.setAll(false) }
    }
}

@Composable
fun Pill(text: String, color: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        text,
        color = color,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(shape)
            .border(1.dp, color.copy(alpha = 0.5f), shape)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
fun SectionTitle(title: String) {
    Text(
        title,
        color = LgText,
        fontSize = 13.sp,
        fontWeight = FontWeight.ExtraBold,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(top = 10.dp)
    )
}

@Composable
fun FeatureCard(f: Feature, on: Boolean, delayMs: Long, onChange: (Boolean) -> Unit) {
    var shown by rememberSaveable(f.id) { mutableStateOf(false) }
    LaunchedEffect(f.id) {
        if (!shown) {
            delay(delayMs)
            shown = true
        }
    }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 4 }
    ) {
        val border by animateColorAsState(if (on) LgPurple.copy(alpha = 0.8f) else LgBorder, tween(300), label = "b")
        val bg by animateColorAsState(if (on) Color(0xFF1A1426) else LgCard, tween(300), label = "bg")
        val shape = RoundedCornerShape(18.dp)
        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(bg)
                .border(1.dp, border, shape)
                .clickable { onChange(!on) }
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(f.emoji, fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(f.title, color = LgText, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                Text(f.desc, color = LgMuted, fontSize = 12.sp, lineHeight = 16.sp)
                Spacer(Modifier.height(6.dp))
                EffectChip(f)
            }
            Spacer(Modifier.width(10.dp))
            NeonSwitch(on)
        }
    }
}

@Composable
fun EffectChip(f: Feature) {
    val c = if (f.effect == Effect.REAL) LgGreen else LgAmber
    val label = if (f.oneShot) "${f.effect.label} · ACCIÓN ÚNICA" else f.effect.label
    Text(
        label,
        color = c,
        fontSize = 9.5.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(c.copy(alpha = 0.12f))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    )
}

@Composable
fun NeonSwitch(on: Boolean) {
    val x: Dp by animateDpAsState(
        if (on) 22.dp else 0.dp,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "x"
    )
    val track by animateColorAsState(if (on) LgPurple else Color(0xFF2A2A36), tween(250), label = "track")
    val knob by animateColorAsState(if (on) Color.White else Color(0xFF8A8A9A), tween(250), label = "knob")
    Box(
        Modifier
            .width(52.dp)
            .height(30.dp)
            .clip(CircleShape)
            .background(track)
            .padding(3.dp)
    ) {
        Box(
            Modifier
                .offset(x = x)
                .size(24.dp)
                .clip(CircleShape)
                .background(knob)
        )
    }
}

// ---------------- Footer ----------------

@Composable
fun Footer(vm: MainViewModel) {
    Column(Modifier.fillMaxWidth()) {
        Spacer(Modifier.height(8.dp))
        val shape = RoundedCornerShape(18.dp)
        Box(
            Modifier
                .fillMaxWidth()
                .height(54.dp)
                .clip(shape)
                .border(1.dp, LgRed, shape)
                .clickable { vm.restoreAll() },
            contentAlignment = Alignment.Center
        ) {
            Text("🗑️ Borrar Todo", color = Color(0xFFFF6B86), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        }
        Spacer(Modifier.height(14.dp))
        Note("⚠️ $DISCLAIMER", LgRed, Color(0xFFFFB4C0))
        Spacer(Modifier.height(12.dp))
        Note("⚠️ $DISCLAIMER2", LgAmber, Color(0xFFFCD9A0))
        Spacer(Modifier.height(28.dp))
        MadeBy()
    }
}

@Composable
fun Note(text: String, border: Color, textColor: Color) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(border.copy(alpha = 0.10f))
            .border(1.dp, border.copy(alpha = 0.5f), shape)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = textColor, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}
