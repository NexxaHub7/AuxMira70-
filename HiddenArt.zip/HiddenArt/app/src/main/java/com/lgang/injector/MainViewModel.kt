package com.lgang.injector

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainViewModel(app: Application) : AndroidViewModel(app) {

    enum class Phase { IDLE, RUNNING, DONE, ERROR }
    enum class Sz { OFF, NO_PERM, READY }
    enum class Screen { KEY, WAIT, PICK, PANEL, ADMIN }

    private val ctx: Context get() = getApplication<Application>().applicationContext
    private val prefs = ctx.getSharedPreferences("lgang_ui", Context.MODE_PRIVATE)
    private val injector = Injector(ctx)
    val keys = KeyStore(ctx)

    // ---- navegación / keys ----
    var screen by mutableStateOf(Screen.KEY)
        private set
    var pkg by mutableStateOf<String?>(null)
        private set
    var keyInput by mutableStateOf("")
    var keyError by mutableStateOf("")
        private set
    var waitLeft by mutableIntStateOf(WAIT_SECONDS)
        private set
    var generatedKey by mutableStateOf<String?>(null)
        private set
    var ownerDialog by mutableStateOf(false)
        private set
    var ownerMsg by mutableStateOf("")
        private set
    val keyList = mutableStateListOf<KeyInfo>()

    // ---- panel ----
    var sz by mutableStateOf(Sz.OFF)
        private set
    var szMode by mutableStateOf("")
        private set
    var game by mutableStateOf<String?>(null)
        private set
    var phase by mutableStateOf(Phase.IDLE)
        private set
    var progress by mutableFloatStateOf(0f)
        private set
    var message by mutableStateOf<String?>(null)
        private set

    val log = mutableStateListOf<String>()
    val enabled = mutableStateMapOf<String, Boolean>()

    private var waitJob: Job? = null
    private var taps = 0
    private var lastTap = 0L

    init {
        Features.all.forEach { enabled[it.id] = prefs.getBoolean("on_${it.id}", it.defaultOn) }
        pkg = prefs.getString("pkg", null)
        val se = prefs.getLong("session_exp", -1L)
        if (se == 0L || (se > 0L && System.currentTimeMillis() < se)) {
            screen = if (pkg != null) Screen.PANEL else Screen.PICK
        }
        refreshShizuku()
    }

    private fun installedPkg(): String? = pkg?.takeIf { GameFinder.isInstalled(ctx, it) }

    // ---------------- Keys ----------------

    fun login() {
        val r = keys.login(keyInput)
        when (r.status) {
            LoginStatus.OK -> {
                keyError = ""
                keyInput = ""
                prefs.edit().putLong("session_exp", r.exp).apply()
                screen = Screen.PICK
            }
            LoginStatus.EMPTY -> keyError = "❌ Escribe tu key"
            LoginStatus.MISSING -> keyError = "❌ Key inexistente"
            LoginStatus.EXPIRED -> keyError = "❌ Key expirada"
            LoginStatus.USED -> keyError = "❌ Esta key ya fue usada"
        }
    }

    fun startWait() {
        waitJob?.cancel()
        screen = Screen.WAIT
        generatedKey = null
        waitLeft = WAIT_SECONDS
        waitJob = viewModelScope.launch {
            while (waitLeft > 0) {
                delay(1000)
                waitLeft--
            }
            generatedKey = keys.generate()
        }
    }

    fun useGenerated() {
        keyInput = generatedKey.orEmpty()
        keyError = ""
        screen = Screen.KEY
    }

    fun choosePkg(p: String) {
        pkg = p
        prefs.edit().putString("pkg", p).apply()
        refreshShizuku()
        screen = Screen.PANEL
    }

    fun changePkg() {
        if (phase != Phase.RUNNING) screen = Screen.PICK
    }

    fun back() {
        when (screen) {
            Screen.WAIT -> {
                waitJob?.cancel()
                screen = Screen.KEY
            }
            Screen.PICK -> screen = Screen.KEY
            Screen.PANEL -> changePkg()
            Screen.ADMIN -> screen = Screen.KEY
            Screen.KEY -> {}
        }
    }

    // ---------------- Owner ----------------

    fun onKeyTap() {
        val now = System.currentTimeMillis()
        if (now - lastTap > 2000) taps = 0
        lastTap = now
        taps++
        if (taps >= 5) {
            taps = 0
            ownerMsg = if (keys.ownerLocked()) "Acceso bloqueado" else ""
            ownerDialog = true
        }
    }

    val ownerLocked: Boolean get() = keys.ownerLocked()

    fun closeOwner() {
        ownerDialog = false
    }

    fun ownerSubmit(input: String) {
        when (keys.ownerTry(input)) {
            OwnerResult.OK -> {
                ownerDialog = false
                ownerMsg = ""
                refreshAdmin()
                screen = Screen.ADMIN
            }
            OwnerResult.WRONG -> ownerMsg = "Key incorrecta"
            OwnerResult.LOCKED -> ownerMsg = "Acceso bloqueado"
        }
    }

    fun refreshAdmin() {
        keyList.clear()
        keyList.addAll(keys.all())
    }

    fun adminGenerate(custom: String?, o: GenOpts, qty: Int): Pair<List<String>, String> {
        val out = mutableListOf<String>()
        var err = ""
        if (custom != null) {
            val k = keys.generateCustom(custom, o)
            if (k == null) err = "❌ Vacía o ya existe" else out.add(k)
        } else {
            for (i in 0 until qty) {
                val k = keys.generate(o)
                if (k == null) {
                    err = "⚠️ Sin combinaciones libres"
                    break
                }
                out.add(k)
            }
        }
        refreshAdmin()
        return out to err
    }

    fun adminDelete(k: String) {
        keys.delete(k)
        refreshAdmin()
    }

    fun adminClean() {
        keys.cleanUp()
        refreshAdmin()
    }

    // ---------------- Shizuku ----------------

    fun refreshShizuku() {
        sz = when {
            !ShizukuHelper.isRunning() -> Sz.OFF
            !ShizukuHelper.hasPermission() -> Sz.NO_PERM
            else -> Sz.READY
        }
        szMode = if (sz == Sz.READY) ShizukuHelper.modeLabel() else ""
        game = installedPkg()
    }

    fun onShizukuTap() {
        try {
            when (sz) {
                Sz.OFF -> openShizukuApp()
                Sz.NO_PERM ->
                    if (Shizuku.shouldShowRequestPermissionRationale()) {
                        say("Concede el permiso desde la app Shizuku.")
                        openShizukuApp()
                    } else {
                        Shizuku.requestPermission(REQ_CODE)
                    }
                Sz.READY -> {}
            }
        } catch (t: Throwable) {
            say("Shizuku requerido: ${t.message}")
        }
    }

    private fun openShizukuApp() {
        val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } else {
            say("Shizuku requerido: instálalo e inícialo.")
        }
    }

    // ---------------- UI state ----------------

    fun setEnabled(id: String, value: Boolean) {
        enabled[id] = value
        prefs.edit().putBoolean("on_$id", value).apply()
        if (phase == Phase.DONE) phase = Phase.IDLE
    }

    fun setAll(value: Boolean) = Features.all.forEach { setEnabled(it.id, value) }

    private fun say(msg: String) {
        message = msg
        viewModelScope.launch {
            delay(4500)
            if (message == msg) message = null
        }
    }

    private fun add(line: String) {
        log.add(line)
    }

    // ---------------- Inyectar ----------------

    fun inject() {
        if (phase == Phase.RUNNING) return
        refreshShizuku()
        if (sz != Sz.READY) {
            say(if (sz == Sz.OFF) "Shizuku requerido: inícialo y vuelve." else "Shizuku requerido: concede el permiso.")
            onShizukuTap()
            return
        }
        viewModelScope.launch {
            try {
                phase = Phase.RUNNING
                progress = 0f
                log.clear()
                val g = installedPkg()
                game = g
                val all = Features.all
                add("💧 L-GANG BOOST — iniciando…")
                add("🔑 Shizuku modo ${ShizukuHelper.modeLabel()}")

                all.forEachIndexed { i, f ->
                    val on = enabled[f.id] == true
                    val wasApplied = prefs.getBoolean("applied_${f.id}", false)
                    if (on) {
                        val r = injector.apply(f, g)
                        when (r) {
                            Outcome.OK -> add("✓ ${f.title}")
                            Outcome.PARTIAL -> add("⚠ ${f.title} (parcial: tu ROM rechazó algo)")
                            Outcome.NO_GAME -> add("✗ ${f.title} (requiere Free Fire instalado)")
                            Outcome.NO_ROOT -> add("✗ ${f.title} (requiere Shizuku en modo ROOT)")
                        }
                        val applied = !f.oneShot && r != Outcome.NO_GAME && r != Outcome.NO_ROOT
                        prefs.edit().putBoolean("applied_${f.id}", applied).apply()
                    } else if (wasApplied) {
                        injector.revert(f, g)
                        prefs.edit().putBoolean("applied_${f.id}", false).apply()
                        add("↩ ${f.title} restaurado")
                    }
                    progress = (i + 1f) / all.size
                    delay(130)
                }

                if (g == null) {
                    add("✗ ${label()} no está instalado")
                    Notifier.error(ctx)
                    add("⚠️ $DISCLAIMER")
                    add("⚠️ $DISCLAIMER2")
                    phase = Phase.ERROR
                    return@launch
                }

                add("✓ ${label()} detectado")
                add("🚀 L-GANG ACTIVADO")
                Notifier.success(ctx)
                Notifier.status(ctx)
                add("⚠️ $DISCLAIMER")
                add("⚠️ $DISCLAIMER2")
                phase = Phase.DONE
                delay(1500)
                openGame(g)
            } catch (t: Throwable) {
                add("✗ Error: ${t.message}")
                phase = Phase.ERROR
            }
        }
    }

    private fun label(): String = if (pkg == PKG_MAX) "Free Fire MAX" else "Free Fire"

    private suspend fun openGame(p: String) {
        val i = ctx.packageManager.getLaunchIntentForPackage(p)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } else {
            ShizukuHelper.exec("monkey -p $p 1")
        }
    }

    // ---------------- Borrar todo ----------------

    fun restoreAll() {
        if (phase == Phase.RUNNING) return
        refreshShizuku()
        if (sz != Sz.READY) {
            say("Shizuku requerido para borrar los ajustes.")
            return
        }
        viewModelScope.launch {
            phase = Phase.RUNNING
            progress = 0f
            log.clear()
            val g = installedPkg()
            val all = Features.all
            all.forEachIndexed { i, f ->
                if (prefs.getBoolean("applied_${f.id}", false)) {
                    injector.revert(f, g)
                    prefs.edit().putBoolean("applied_${f.id}", false).apply()
                    add("↩ ${f.title}")
                }
                progress = (i + 1f) / all.size
                delay(60)
            }
            Notifier.clear(ctx)
            add("↩ Todo borrado y revertido")
            phase = Phase.IDLE
        }
    }

    private companion object {
        const val REQ_CODE = 4242
    }
}
