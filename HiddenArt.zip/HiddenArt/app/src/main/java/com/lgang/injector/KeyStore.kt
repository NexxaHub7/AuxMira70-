package com.lgang.injector

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

const val DAY_MS = 86_400_000L
const val WAIT_SECONDS = 110

data class KeyInfo(val key: String, val created: Long, val exp: Long, val used: Int, val max: Int) {
    val expired: Boolean get() = exp != 0L && System.currentTimeMillis() > exp
    val spent: Boolean get() = used >= max
}

enum class Charset(val label: String, val chars: String) {
    HEX("Hex", "0123456789abcdef"),
    NUM("Números", "0123456789"),
    ALNUM("Letras+núm.", "abcdefghijklmnopqrstuvwxyz0123456789")
}

/** durMs = 0 → permanente */
data class GenOpts(
    val prefix: String = "hiddenart",
    val blocks: Int = 2,
    val digits: Int = 8,
    val charset: Charset = Charset.HEX,
    val durMs: Long = DAY_MS,
    val max: Int = 1
)

enum class LoginStatus { OK, EMPTY, MISSING, EXPIRED, USED }
data class LoginResult(val status: LoginStatus, val exp: Long = 0L)
enum class OwnerResult { OK, WRONG, LOCKED }

class KeyStore(ctx: Context) {

    private val p = ctx.getSharedPreferences("ha_keys", Context.MODE_PRIVATE)
    private val rng = SecureRandom()

    fun clean(s: String): String =
        s.lowercase().trim().replace(Regex("\\s+"), "-").replace(Regex("[^a-z0-9_.-]"), "")

    private fun load(): MutableMap<String, KeyInfo> {
        val out = linkedMapOf<String, KeyInfo>()
        try {
            val o = JSONObject(p.getString("keys", "{}") ?: "{}")
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                out[k] = KeyInfo(k, a.getLong(0), a.getLong(1), a.getInt(2), a.getInt(3))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun save(m: Map<String, KeyInfo>) {
        val o = JSONObject()
        m.values.forEach { o.put(it.key, JSONArray().put(it.created).put(it.exp).put(it.used).put(it.max)) }
        p.edit().putString("keys", o.toString()).apply()
    }

    fun all(): List<KeyInfo> = load().values.sortedByDescending { it.created }

    private fun rnd(n: Int, cs: String): String =
        buildString { repeat(n) { append(cs[rng.nextInt(cs.length)]) } }

    /** Genera una key aleatoria (solo texto, no la guarda). */
    fun mk(o: GenOpts): String =
        (listOf(clean(o.prefix)) + List(o.blocks) { rnd(o.digits, o.charset.chars) })
            .filter { it.isNotEmpty() }
            .joinToString("-")

    private fun put(m: MutableMap<String, KeyInfo>, k: String, o: GenOpts) {
        val now = System.currentTimeMillis()
        m[k] = KeyInfo(k, now, if (o.durMs == 0L) 0L else now + o.durMs, 0, o.max)
        save(m)
    }

    fun generate(o: GenOpts = GenOpts()): String? {
        val m = load()
        repeat(60) {
            val k = mk(o)
            if (!m.containsKey(k)) {
                put(m, k, o)
                return k
            }
        }
        return null
    }

    fun generateCustom(raw: String, o: GenOpts): String? {
        val k = clean(raw)
        val m = load()
        if (k.isEmpty() || m.containsKey(k)) return null
        put(m, k, o)
        return k
    }

    fun delete(k: String) {
        val m = load()
        m.remove(k)
        save(m)
    }

    fun cleanUp() {
        val m = load()
        m.values.removeAll { it.expired || it.spent }
        save(m)
    }

    /** Valida y consume un uso. */
    fun login(raw: String): LoginResult {
        val k = raw.trim().lowercase()
        if (k.isEmpty()) return LoginResult(LoginStatus.EMPTY)
        val m = load()
        val d = m[k] ?: return LoginResult(LoginStatus.MISSING)
        if (d.expired) return LoginResult(LoginStatus.EXPIRED)
        if (d.spent) return LoginResult(LoginStatus.USED)
        m[k] = d.copy(used = d.used + 1)
        save(m)
        return LoginResult(LoginStatus.OK, d.exp)
    }

    // ---------------- Owner ----------------

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun ownerLocked(): Boolean = p.getBoolean("o_locked", false)

    fun ownerTry(input: String): OwnerResult {
        if (ownerLocked()) return OwnerResult.LOCKED
        if (sha("ha:" + input.trim().lowercase()) == OWNER_HASH) {
            p.edit().putInt("o_fails", 0).commit()
            return OwnerResult.OK
        }
        val f = p.getInt("o_fails", 0) + 1
        p.edit().putInt("o_fails", f).commit()
        if (f >= 3) {
            p.edit().putBoolean("o_locked", true).commit()
            return OwnerResult.LOCKED
        }
        return OwnerResult.WRONG
    }

    private companion object {
        const val OWNER_HASH = "f0892a899c4c6ff8800096de23d4fd2f76e085f803a4efaa6c74cdc6631c62de"
    }
}
