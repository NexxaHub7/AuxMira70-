package com.lgang.injector

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object Notifier {
    private const val CH = "lgang_main"
    private const val ID_OK = 1001
    private const val ID_STATUS = 1002
    private const val ID_ERR = 1003

    suspend fun success(ctx: Context) =
        show(ctx, ID_OK, "⚡ L-Gang Android", "Atajo L-Gang Activado Exitosamente. ✅", timeoutMs = 10_000)

    suspend fun status(ctx: Context) =
        show(ctx, ID_STATUS, "💧 L-Gang Sensi", "L-Gang sensi activo...", ongoing = true)

    suspend fun error(ctx: Context) =
        show(ctx, ID_ERR, "⚡ L-Gang Android", "Free Fire no encontrado.")

    fun clear(ctx: Context) {
        val nm = NotificationManagerCompat.from(ctx)
        nm.cancel(ID_OK); nm.cancel(ID_STATUS); nm.cancel(ID_ERR)
    }

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(NotificationChannel(CH, "L-Gang", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun build(ctx: Context, title: String, text: String, ongoing: Boolean, timeoutMs: Long): Notification {
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat_lgang)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setAutoCancel(!ongoing)
            .setColor(0xFFFF2D55.toInt())
        if (timeoutMs > 0) b.setTimeoutAfter(timeoutMs)
        return b.build()
    }

    @SuppressLint("MissingPermission")
    private suspend fun show(
        ctx: Context, id: Int, title: String, text: String,
        ongoing: Boolean = false, timeoutMs: Long = 0L
    ) {
        ensureChannel(ctx)
        val nm = NotificationManagerCompat.from(ctx)
        if (nm.areNotificationsEnabled()) {
            try {
                nm.notify(id, build(ctx, title, text, ongoing, timeoutMs))
                return
            } catch (_: SecurityException) {
            }
        }
        // Sin permiso de notificaciones: se publica vía Shizuku, así siempre aparece.
        ShizukuHelper.exec("cmd notification post -t ${q(title)} lg_$id ${q(text)}")
    }
}
