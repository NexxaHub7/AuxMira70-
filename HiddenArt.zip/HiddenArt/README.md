# Hidden Art — Auxilio de mira legal (Free Fire)

App Android (Kotlin + Jetpack Compose + Shizuku). Cambia ajustes **de tu dispositivo**; no toca ni inyecta nada dentro de Free Fire.

## Compilar
Android Studio (Koala o más nuevo) → *Open* → esta carpeta → esperar el Sync → ▶ o *Build > Build APK(s)*. Android 8+ (probado para 14).

## Flujo
1. **Key**: escribe tu key y *Login*, o *Get Key* (contador de 1:50 y genera `hiddenart-xxxxxxxx-xxxxxxxx`, un solo uso, 24 h).
2. **Escoge qué Free Fire tienes** (normal `com.dts.freefireth` / Max `com.dts.freefiremax`). Se puede cambiar con *Cambiar*.
3. **Panel**: toggles + *Inyectar En FreeFire* (aplica, notifica y abre el juego). *Borrar Todo* revierte todo.
4. Requiere **Shizuku** iniciado (modo ROOT si tienes root; si no, ADB).

## Toggles
| Toggle | Estado |
|---|---|
| Performance, Animaciones, Memoria, Refresh 120 Hz, Resolución, DPI, Limpiar caché, Compilar | Efectivos en Android estándar |
| Mira Estable, Respuesta Táctil, Sensi/Toques, Supresor, Background Process, FPS Boost | Solo si tu ROM lee esas claves |
| Colores vivos | Saturación de **toda** la pantalla, requiere Shizuku en ROOT |

- Las keys se validan en el propio teléfono (no hay servidor).
- Resolución/DPI: si algo se ve mal usa *Borrar Todo* o `adb shell wm size reset; wm density reset`.

**No nos hacemos responsables de daños en tu dispositivo.**
